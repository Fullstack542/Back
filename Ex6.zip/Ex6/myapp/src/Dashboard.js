import React from "react";

function Dashboard({ user }) {
  return (
    <div style={{ textAlign: "center", marginTop: "100px" }}>
      <h2>Welcome, {user.name}!</h2>
      <p>Role: {user.role}</p>

      {user.role === "admin" ? (
        <div>
          <h3>Admin Panel</h3>
          <p>You can manage users and settings.</p>
        </div>
      ) : (
        <div>
          <h3>User Dashboard</h3>
          <p>You can view your personal data here.</p>
        </div>
      )}
    </div>
  );
}

export default Dashboard;
