import React, { useEffect, useState } from "react";
import axios from "axios";

function App() {
  const [users, setUsers] = useState([]);
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");

  // ✅ Fetch users
  const fetchUsers = async () => {
    const res = await axios.get("http://localhost:5000/users");
    setUsers(res.data);
  };

  // ✅ Add user
  const handleSubmit = async (e) => {
    e.preventDefault();
    await axios.post("http://localhost:5000/users", { name, email });
    setName("");
    setEmail("");
    fetchUsers(); // refresh
  };

//   In HTML forms, when you click “Submit,” the browser normally refreshes the page.
// e.preventDefault() stops that default behavior.

  // ✅ Delete user
  const handleDelete = async (id) => {
    if (window.confirm("Are you sure you want to delete this user?")) {
      await axios.delete(`http://localhost:5000/users/${id}`);
      fetchUsers(); // refresh after delete
    }
  };

  useEffect(() => {
    fetchUsers();
  }, []);

  return (
    <div style={{ textAlign: "center", marginTop: "50px" }}>
      <h2>React + MongoDB (Insert, Fetch, Delete)</h2>

      <form onSubmit={handleSubmit}>
        <input
          type="text"
          placeholder="Enter name"
          value={name}
          onChange={(e) => setName(e.target.value)}
          required
        />{" "}
        <input
          type="email"
          placeholder="Enter email"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          required
        />{" "}
        <button type="submit">Add User</button>
      </form>

      <h3 style={{ marginTop: "30px" }}>User List</h3>
      <ul style={{ listStyle: "none" }}>
        {users.map((u) => (
          <li key={u._id}>
            <b>{u.name}</b> — {u.email}{" "}
            <button
              onClick={() => handleDelete(u._id)}
              style={{ marginLeft: "10px", color: "white", background: "red", border: "none", padding: "4px 8px", cursor: "pointer" }}
            >
              Delete
            </button>
          </li>
        ))}
      </ul>
    </div>
  );
}

export default App;
