import React, { useState } from "react";

function Message() {
  const [message, setMessage] = useState("Welcome!");

  return (
    <div style={{ marginTop: "30px" }}>
      <h2>{message}</h2>
      <button onClick={() => setMessage("Hello, React!")}>Change Message</button>
    </div>
  );
}

export default Message;