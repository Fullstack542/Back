import { createContext, useContext, useState } from "react";

// Step 1: Create context
const ThemeContext = createContext();

// Step 2: Create provider
export const ThemeProvider = ({ children }) => {
  const [theme, setTheme] = useState("light");

  const toggleTheme = () => {
    setTheme((prev) => (prev === "light" ? "dark" : "light"));
  };

  return (
    <ThemeContext.Provider value={{ theme, toggleTheme }}>
      {children}
    </ThemeContext.Provider>
  );
};

// Step 3: Create a hook for easy access
export const useTheme = () => useContext(ThemeContext);